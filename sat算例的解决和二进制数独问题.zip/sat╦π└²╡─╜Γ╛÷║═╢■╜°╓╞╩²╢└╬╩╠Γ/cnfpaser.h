#ifndef __CNFPASER_H__
#define __CNFPASER_H__
#include"sover.h"
status DPLL(Formular* s,Answer* answer,time_t* time);//DPLL�㷨������
status DPLL(Formular* s,Answer* answer,time_t* time)
{
	Formular* adds,*p,*q;
	status condition1,condition2;
	Elemtype elem;
	elem=single(s);
	if(elem!=0){
		if(elem>0){
			answer->solution[elem]=1;
		}
		else answer->solution[0-elem]=0;
		Delete(s,elem);
		//printf("%d	",elem);���ڲ鿴ִ�й���
		if(DeleteAll(s)){
			answer->answer=1;
			*time=clock();
			return TRUE;
		}
		if(Empty(s)) {
			*time=clock();
			answer->answer=0;
			return FALSE;
		}
  		elem=single(s);
		if(elem!=0)
  		if(DPLL(s,answer,time)){
  			answer->answer=1;
  			return TRUE;
		  }
  		else{
  			BackDelete(s,elem);
  			answer->answer=0;
  			return FALSE;
  		}
	}
	elem=Choose(s);
	if(DPLL(Add(s,elem),answer,time)){
		answer->answer=1;
		return TRUE;
	}
	s=BackDelete(s,elem);
	s=Add(s,0-elem);
	if(DPLL(s,answer,time)){
		answer->answer=1;
		return TRUE;
	}
	else{
		BackDelete(s,0-elem);
		answer->answer=0;
		return FALSE;
	}
}
#endif
