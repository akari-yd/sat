#ifndef __BINARYPUZZLE_H__
#define __BINARYPUZZLE_H__

#include"cnfpaser.h"
#include"sover.h"
#include<malloc.h>

Formular* transfercnf(Formular* s);//��������Ϸת��Ϊcnf
Formular* readgame();//���û����ж�ȡ��Ϸ
Formular* creatgame(Formular* s);//�Զ�����������Ϸ
Formular* constraint1(Formular* s);//Լ��1ת��Ϊcnf
Formular* constraint2(Formular* s);//Լ��2ת��Ϊcnf
Formular* constraint3(Formular* s);//Լ��3ת��Ϊcnf
Formular* addclause(Formular* s,character* ch,int j1,int j2,int k);//�����ӱ�Ԫת��Ϊcnf��Ԫ

int m;
Formular* transfercnf(Formular* s)
{
	//printf("��ѡ�� ����/�Զ����ɣ�0/1�� ������Ϸ��");
	int mode=0;
	//scanf("%d",&mode);
	if(mode==0){
		s=readgame();
		if(s->next==NULL) return s;
	}
	else if(mode==1){
		s=creatgame(s);
		if(s->next==NULL) return s;
	}
	else {
		printf("�������");
		s->next=NULL;
		return s;
	}
	s=constraint1(s);
	s=constraint2(s);
	s=constraint3(s);
	return s;
}
Formular* readgame()
{
	Formular* p,*q;
	p=(Formular*)malloc(sizeof(Formular));
	p->next=NULL;
	q=p;
	printf("������һ��ż����Ϊ������");
	scanf("%d",&m);
	getchar();
	if(m%2==1){
		printf("�������");
		p->next=NULL;
		return q;
	}
	p->clause.number=m;
	printf("������%d���ַ���",m*m);
	for(int i=1;i<=m;i++){
		for(int j=1;j<=m;j++){
			char ch;
			ch=getchar();
			if(ch=='1'){
				p->next=(Formular*)malloc(sizeof(Formular));
				p->next->clause.condition=0;
				p->next->clause.number=1;
				p->next->clause.ch[0].elem=(i-1)*m+j;
				p->next->clause.ch[0].mark=1;
				p->next->clause.ch[1].mark=-1;
				p=p->next;
			}
			else if(ch=='0'){
				p->next=(Formular*)malloc(sizeof(Formular));
				p->next->clause.number=1;
				p->next->clause.condition=0;
				p->next->clause.ch[0].elem=0-((i-1)*m+j);
				p->next->clause.ch[0].mark=1;
				p->next->clause.ch[1].mark=-1;
				p=p->next;
			}
		}
	}p->next=NULL;
	return q;
}
Formular* creatgame(Formular* s)
{
	Formular* p;
	p=s;
	p->next=NULL;
	return s;
}
Formular* constraint1(Formular* s)
{
	Formular* p,*q;
	p=s;
	for(int i=1;i<=m;i++){
		for(int j=1;j<m-1;j++){
			q=p->next;
			p->next=(Formular*)malloc(sizeof(Formular));
			p->next->next=q;
			p->next->clause.condition=0;
			p->next->clause.number=3;
			p->next->clause.ch[0].elem=(i-1)*m+j;
			p->next->clause.ch[0].mark=1;
			p->next->clause.ch[1].elem=(i-1)*m+j+1;
			p->next->clause.ch[1].mark=1;
			p->next->clause.ch[2].elem=(i-1)*m+j+2;
			p->next->clause.ch[2].mark=1;
			p->next->clause.ch[3].mark=-1;
			q=p->next;
			p->next=(Formular*)malloc(sizeof(Formular));
			p->next->next=q;
			p->next->clause.condition=0;
			p->next->clause.number=3;
			p->next->clause.ch[0].elem=0-(i-1)*m-j;
			p->next->clause.ch[0].mark=1;
			p->next->clause.ch[1].elem=0-(i-1)*m-j-1;
			p->next->clause.ch[1].mark=1;
			p->next->clause.ch[2].elem=0-(i-1)*m-j-2;
			p->next->clause.ch[2].mark=1;
			p->next->clause.ch[3].mark=-1;
			//�����д����������д���
			q=p->next;
			p->next=(Formular*)malloc(sizeof(Formular));
			p->next->next=q;
			p->next->clause.condition=0;
			p->next->clause.number=3;
			p->next->clause.ch[0].elem=(j-1)*m+i;
			p->next->clause.ch[0].mark=1;
			p->next->clause.ch[1].elem=(j-1)*m+i+1;
			p->next->clause.ch[1].mark=1;
			p->next->clause.ch[2].elem=(j-1)*m+i+2;
			p->next->clause.ch[2].mark=1;
			p->next->clause.ch[3].mark=-1;
			q=p->next;
			p->next=(Formular*)malloc(sizeof(Formular));
			p->next->next=q;
			p->next->clause.condition=0;
			p->next->clause.number=3;
			p->next->clause.ch[0].elem=0-(j-1)*m-i;
			p->next->clause.ch[0].mark=1;
			p->next->clause.ch[1].elem=0-(j-1)*m-i-1;
			p->next->clause.ch[1].mark=1;
			p->next->clause.ch[2].elem=0-(j-1)*m-i-2;
			p->next->clause.ch[2].mark=1;
			p->next->clause.ch[3].mark=-1;
		}
	}
	return s;
}
Formular* constraint2(Formular* s)
{
	Formular* p;
	int list[10];
	list[0]=0;
	for(int i=1;i<=m;i++){
		for(int j=0;j<=m/2;j++){
			for(int k=list[j]+1;k<=j+m/2;k++){
				list[j+1]=k;
				if(j==m/2){
					p=s->next;
					s->next=(Formular*)malloc(sizeof(Formular));
					s->next->clause.number=m/2+1;
					s->next->clause.condition=0;
					for(int x=0;x<m/2+1;x++){
						s->next->clause.ch[x].elem=(i-1)*m+list[x+1];
						s->next->clause.ch[x].mark=1;
					}s->next->clause.ch[m/2+1].mark=-1;
					s->next->next=p;
					p=s->next;
					s->next=(Formular*)malloc(sizeof(Formular));
					s->next->clause.number=m/2+1;
					s->next->clause.condition=0;
					for(int x=0;x<m/2+1;x++){
						s->next->clause.ch[x].elem=0-(i-1)*m-list[x+1];
						s->next->clause.ch[x].mark=1;
					}s->next->clause.ch[m/2+1].mark=-1;
					s->next->next=p;
					//�����д����������д���
					p=s->next;
					s->next=(Formular*)malloc(sizeof(Formular));
					s->next->clause.number=m/2+1;
					s->next->clause.condition=0;
					for(int x=0;x<m/2+1;x++){
						s->next->clause.ch[x].elem=i+(list[x+1]-1)*m;
						s->next->clause.ch[x].mark=1;
					}s->next->clause.ch[m/2+1].mark=-1;
					s->next->next=p;
					p=s->next;
					s->next=(Formular*)malloc(sizeof(Formular));
					s->next->clause.number=m/2+1;
					s->next->clause.condition=0;
					for(int x=0;x<m/2+1;x++){
						s->next->clause.ch[x].elem=0-i-(list[x+1]-1)*m;
						s->next->clause.ch[x].mark=1;
					}s->next->clause.ch[m/2+1].mark=-1;
					s->next->next=p;
				}
			}
		}
	}
	return s;
}
Formular* constraint3(Formular* s)
{
	Formular* p;
	character ch[ch_max_num];
	for(int j1=1;j1<m;j1++){
		for(int j2=j1+1;j2<m+1;j2++){
			s=addclause(s,ch,j1,j2,m);
		}
	}
	return s;
}
Formular* addclause(Formular* s,character* ch,int j1,int j2,int k)
{
	if(k!=0){
		ch[2*k].mark=m*(k-1)+j1;
		ch[2*k-1].elem=0-m*(k-1)-j1;
		s=addclause(s,ch,j1,j2,k-1);
		ch[2*k].elem=m*(k-1)+j2;
		ch[2*k-1].elem=0-m*(k-1)-j2;
		s=addclause(s,ch,j1,j2,k-1);
		ch[2*k].elem=m*(k-1)+j1;
		ch[2*k-1].elem=m*(k-1)+j2;
		s=addclause(s,ch,j1,j2,k-1);
		ch[2*k].elem=0-m*(k-1)-j1;
		ch[2*k-1].elem=0-m*(k-1)-j2;
		s=addclause(s,ch,j1,j2,k-1);
		ch[2*k].elem=m*(j1-1)+k;
		ch[2*k-1].elem=m*(j2-1)+k;
		s=addclause(s,ch,j1,j2,k-1);
		ch[2*k].elem=0-m*(j1-1)-k;
		ch[2*k-1].elem=0-m*(j2-1)-k;
		s=addclause(s,ch,j1,j2,k-1);
		ch[2*k].elem=m*(j1-1)+k;
		ch[2*k-1].elem=0-m*(j1-1)-k;
		s=addclause(s,ch,j1,j2,k-1);
		ch[2*k].elem=m*(j2-1)+k;
		ch[2*k-1].elem=0-m*(j2-1)-k;
		s=addclause(s,ch,j1,j2,k-1);
		return s;
	}
	else{
		Formular* p;
		p=s->next;
		s->next=(Formular*)malloc(sizeof(Formular));
		s->next->next=p;
		s->next->clause.condition=0;
		s->next->clause.number=2*m;
		for(int i=1;i<=m;i++){
			s->next->clause.ch[2*i-1 ].elem=ch[2*i].elem;
			s->next->clause.ch[2*i-1].mark=1;
			s->next->clause.ch[2*i-2].elem=ch[2*i-1].elem;
			s->next->clause.ch[2*i-2].mark=1;
		}s->next->clause.ch[2*m].mark=-1;
		return s;
	}
}
#endif
