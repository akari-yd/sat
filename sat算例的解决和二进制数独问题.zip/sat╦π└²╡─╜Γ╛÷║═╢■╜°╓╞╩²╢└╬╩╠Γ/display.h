#ifndef __DISPLAY_H__
#define __DISPLAY_H__

#include<stdio.h>
#include<string.h>
#include"sover.h"
#include"cnfpaser.h"
#include<time.h>
#include"Binarypuzzle.h"

void show();//��������
Formular* creatcnf(char* name);//���ļ��ж�ȡһ��������ʽ
void Deletecnf(Formular* s);//ɾ��һ����ʽ
void SaveAnswer(Formular* s,Answer answer,time_t time,char* name);//��������������.res�ļ���
int Conform(Formular* s,Answer* answer);//��֤����ȷ��
void showanswer(Answer anwer,Formular* s,int mode);//�����
void show()
{
	int op=1;
	time_t time,time1,*time2;
	Formular* s;
	s=NULL;
	time2=(time_t*)malloc(sizeof(time_t));
	Answer* answer;
	answer=(Answer*)malloc(sizeof(Answer));
	char name[50];
	while(op)
	{
		system("cls");printf("\n\n");
		printf("      Menu for Linkedlist Table On Sequence Structure \n");
		printf("-------------------------\n");
		printf("1.creatcnf\n2.Deletecnf\n");
		printf("3.SaveAnswer\n4.ConformAnswer\n");
		printf("5.RunDpll\n6.BinaryPuzzle\n7.show answer\n0.Exit\n");
		printf("--------------------------\n");
		printf("������һ��ָ��0~7��");
			scanf("%d",&op);
		switch (op){
			case 1:
			printf("�����ȡ�ļ������ƣ�");
			scanf("%s",name);
			Deletecnf(s);
			s=creatcnf(name);
			getchar();getchar();
				break;
			case 2:Deletecnf(s);
			printf("ɾ���ɹ���\n");
			getchar();getchar();
				break;
			case 3:SaveAnswer(s,*answer,time,name);
			getchar();getchar();
				break;
			case 4:Conform(s,answer);
			getchar();getchar();
				break;
			case 5:
			if(s==NULL){
				printf("ERROR!\n");
				getchar();
				getchar();
				break;
			}time1=clock();
			DPLL(s,answer,time2);
			time=*time2-time1;
			if(time!=0)
				printf("����ɹ���\n��ʱ%d	ms",time);
			getchar();getchar();
			break;
			case 6:
				Deletecnf(s);
				s=transfercnf(s);
				if(s->next!=NULL){
					printf("��Ϸ���ɣ�\n");
					DPLL(s,answer,time2);
					showanswer(*answer,s,1);
				}
				else{
					printf("���ִ���\n");
				}
				getchar();
				getchar();
				break;
			case 7:
				showanswer(*answer,s,0);
				getchar();
				getchar();
				break;
			case 0:
				break;
		}
	}
}
Formular* creatcnf(char* name)
{
	Formular* s;
	s=readcnf(name);
	if(s->next!=NULL){
		printf("��ȡ�ɹ���");
		return s;
	}
	else{
		printf("��ȡʧ�ܣ�");
		free(s);
		return NULL;
	}
}
void Deletecnf(Formular* s)
{
	if(s){
		while(s->next){
			Formular* p;
			p=s->next;
			free(s);
			s=p;
		}free(s);
	}
}
void SaveAnswer(Formular* s,Answer answer,time_t time,char* name)
{
	if(answer.answer==1||answer.answer==0){
		char* p;
		p=strstr(name,".cnf");
		p[0]='\0';
		FILE* fp;
		fp=fopen(strcat(name,".res"),"w+");
		fprintf(fp,"s %d\n",answer.answer);
		if(answer.answer==1){
			fprintf(fp,"v ");
			for(int i=1;i<answer_length;i++){
				if(i>s->clause.number) break;
				else fprintf(fp,"%d	",answer.solution[i]>0?i:0-i);
			}fprintf(fp,"\n");
		}
		fprintf(fp,"t %d ms",time);
		fclose(fp);
		printf("����ɹ���\n");
	}
	else printf("���Ƚ������㣡\n");
}
int Conform(Formular* s,Answer* answer)
{
	if(answer->answer==0) printf("������֤���ɽ�������\n");
	else if(answer->answer!=1) printf("��δ�������㣡");
	else if(!s) printf("��ʽ�����ڣ�\n");
	else if(!s->next) printf("��ʽ�����ڣ�\n");
	else while(s->next){
		for(int i=0;i<ch_max_num;i++){
			if(s->next->clause.ch[i].mark==-1){
				printf("�𰸴���\n");
				return 0;
			}
			if(s->next->clause.ch[i].elem>0){
				if(answer->solution[s->next->clause.ch[i].elem]) break;
			}
			else {
				if(!answer->solution[0-s->next->clause.ch[i].elem]) break;
			}
		}s=s->next;
	}
	printf("����ȷ��\n");
	return 1;
}
void showanswer(Answer answer,Formular* s,int mode)
{
	if(answer.answer){
		printf("\nThe answer is:\n");
		if(mode==0)
		for(int i=1;i<answer_length;i++){
			if(i>s->clause.number) break;
			printf("%d	",answer.solution[i]>0?i:0-i);
		}
		else{
			for(int i=1;i<=s->clause.number;i++){
				for(int j=1;j<=s->clause.number;j++){
					printf("%d	",answer.solution[(i-1)*s->clause.number+j]);
				}printf("\n");
			}
		}printf("\n");
	}
	else printf("No Answer!");
}
#endif
