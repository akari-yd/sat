#include<stdio.h>
#include"display.h"
#include"sover.h"
#include"BinaryPuzzle.h"
#include"cnfpaser.h"

int main()
{
	show();
	printf("��лʹ�ñ�����");
	getchar();
	getchar();
	return 0;
}
//01****011*1**1**
//***1****0**10***0**11*********1***0*
